# AI Drama Director Skill · AI短剧导演 Skill

**Version 8.2 · Author: mr zhu · [中文](README.md)**

Turn a script into concise storyboard prompts, generating one multi-shot clip per group. Version 8.2 teaches emotional development, continuous sound, coherent space, and action across cuts. Add shots when expression needs them; keep each change of view useful and preserve the source.

## Choose a file

- **For ChatGPT, DeepSeek, or another writing agent:** [Complete 8.2 Markdown](ai短剧导演skill-8.2版.md). The Chinese-language file includes all instruction, diagrams, worked examples, output format, and checks.
- **For reading on a phone or computer:** [PDF with embedded images](AI短剧导演skill_8.2_跨设备阅读版.pdf), or download the [standalone offline HTML](AI短剧导演skill_8.2_离线图文阅读版.html).
- **For offline storage or native installation:** [Illustrated ZIP](AI短剧导演skill_8.2_图文完整版.zip), containing [SKILL.md](ai-drama-director-storyboard/SKILL.md) and local assets. Preserve its folders.
- **For a separate review after a long conversation:** [8.2 review instructions](分镜自检系统_8.2独立版.md). The complete skill remains sufficient on its own.

## What 8.2 teaches

1. Carry a supported emotion from its trigger through visible behavior, the other character's reception, and the next shot. Distinguish an excuse, a suspicion, and a fact.
   Both characters perform during dialogue: a listener responds through gaze, expression, and ongoing action. Fictional examples cover shyness, anger, exasperation, and urgency.
   Infer supported subtext from the full context, checking whether an intervening event changed the cause. Add compatible small gestures within established adult romantic relationships; default to natural, readable emotion.
2. Preserve the full dialogue or inner voice while selecting useful speaker, listener, action, relationship, or environmental coverage. Concurrent reactions do not add time twice.
3. Keep world position, screen direction, anatomical left/right, contact, props, support, and offscreen elapsed time consistent.
4. Give each independently generated group its own necessary starting conditions, including emotional state and unfinished exchanges.
5. Learn from complete fictional examples: a seven-second handoff in one group, a reunion with an observer, jealousy and continuous inner voice, and a daylight moving conversation with sitting, standing, and a third person entering.

The course contains **17 figures, including 6 new diagrams**. Each group totals **an integer from 1 through 30 seconds, inclusive**. Individual boundaries may use decimals but must add up exactly. Ordinary close-ups may start around 2–4 seconds for planning; sustained performance may need longer. Neither shot counts nor these durations are quotas.

The current workflow primarily retains Seed2.5's generated audio. Emotionally active or otherwise flat dialogue may benefit from seven or eight useful shots across twenty seconds, divided into shorter generation groups where appropriate. Figure D distinguishes editing density from generation length. The user's reported failures around seconds 8–12 are observations from this setup, not a universal model limit; group boundaries must also respect speech, action, and emotional continuity.

Continuous visible mouth-to-mouth contact is limited to three seconds under this project's requirements. Changing angles or generation groups does not reset the count. This does not claim universal platform policy or guaranteed approval.

Section 0.0 prioritizes continuity before spoken execution while retaining source fidelity. Figure E teaches concrete performance wording and stable time-of-day conditions; figure F and appendix D demonstrate moving dialogue across two generation groups. All teaching remains in the single complete Markdown.

## Use and evidence

Send the complete Markdown, current source, scope, completed material, and available references, using the [startup instructions](8.2启动指令.txt). Copy one complete production group at a time into the video tool. Keep explanations and review reports outside those prompts.

Each group cites its corresponding character, face, voice, location, and prop references. The user specifies aspect ratio and visual style. Background music is added in post; motivated location sounds may be generated. Post-production can trim pauses, balance levels, splice dialogue, and add captions or readable screen text. Preserve source events when a reference is missing and mark the specific gap in parentheses. Motivated blocking during dialogue is allowed. Deliver the complete checked scope by default; section 11 covers reference roles and diagnosis of different generation failures.

The update retains source fidelity, mandatory content prechecks, verification of suspected adaptation gaps, ensemble coverage, portable illustrations, and concise output. It corrects ambiguous direction wording, door identification, overly restrictive emotion-change wording, and confusion between cuts and camera movement. See the [upgrade and validation record](8.2升级说明与验证记录.md).

The root Markdown uses image URLs pinned to Git commits. Native packages and ZIP use local assets; PDF and HTML embed the figures. The update was checked at the text, example, timing, state-transition, and reading-package levels. Positive user feedback on the previous production revision informed the method. **No new Seed2.5 generation or independent downstream-model test is claimed.** Public examples are fictional and exclude private scripts and video frames.

Historical releases remain available. Use 8.2 for new work and retain attribution **mr zhu** when sharing or quoting it.
